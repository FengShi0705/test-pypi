"""Main module."""


def dummy_func(a: int, b: int) -> int:
    """Dummy function."""
    return a + b
